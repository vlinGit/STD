import{N as $e,S as Ae}from"./index-4708d384.js";import{ar as de,ad as a,as as Ne,d as Z,at as ue,au as pe,av as Me,e as I,aw as Ee,ax as Q,ay as qe,az as Ie,r as z,aA as He,aB as Ve,S as Xe,J as W,aC as Ge,aD as We,aE as Ze,aF as Ke,aG as Qe,aH as $,aI as k,aJ as A,aK as we,aL as G,aM as Je,aN as Ye,aO as Fe,aP as et,aQ as P,aR as tt,aS as nt,aT as rt,aU as at,F as be,aV as ot,aW as xe,v as lt,aX as Re,f as Ue,o as J,c as ae,a as R,m,k as b,_ as ne,aY as it,C as Pe,b as st,h as dt,l as w,E as K,R as Ce,A as le,j as ut,t as ce,p as me,q as ie,s as ve,z as ct,aZ as ft,a_ as pt,a$ as Y,Q as gt,an as ht,b0 as mt,b1 as vt,b2 as bt,U as yt,b3 as wt,b4 as xt,D as Rt,G as _e,b5 as Ct,aq as _t}from"./index-cdd1030a.js";import{N as ke}from"./Popconfirm-186e1d10.js";import{N as kt}from"./Select-7cd636c3.js";import{N as Lt}from"./Switch-c034eb23.js";import"./NumberAnimation-9c0224fa.js";import"./LayoutSider-2a3099b5.js";const Tt=de("attach",a("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},a("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},a("g",{fill:"currentColor","fill-rule":"nonzero"},a("path",{d:"M3.25735931,8.70710678 L7.85355339,4.1109127 C8.82986412,3.13460197 10.4127766,3.13460197 11.3890873,4.1109127 C12.365398,5.08722343 12.365398,6.67013588 11.3890873,7.64644661 L6.08578644,12.9497475 C5.69526215,13.3402718 5.06209717,13.3402718 4.67157288,12.9497475 C4.28104858,12.5592232 4.28104858,11.9260582 4.67157288,11.5355339 L9.97487373,6.23223305 C10.1701359,6.0369709 10.1701359,5.72038841 9.97487373,5.52512627 C9.77961159,5.32986412 9.4630291,5.32986412 9.26776695,5.52512627 L3.96446609,10.8284271 C3.18341751,11.6094757 3.18341751,12.8758057 3.96446609,13.6568542 C4.74551468,14.4379028 6.01184464,14.4379028 6.79289322,13.6568542 L12.0961941,8.35355339 C13.4630291,6.98671837 13.4630291,4.77064094 12.0961941,3.40380592 C10.7293591,2.0369709 8.51328163,2.0369709 7.14644661,3.40380592 L2.55025253,8 C2.35499039,8.19526215 2.35499039,8.51184464 2.55025253,8.70710678 C2.74551468,8.90236893 3.06209717,8.90236893 3.25735931,8.70710678 Z"}))))),Bt=de("trash",a("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},a("path",{d:"M432,144,403.33,419.74A32,32,0,0,1,371.55,448H140.46a32,32,0,0,1-31.78-28.26L80,144",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}),a("rect",{x:"32",y:"64",width:"448",height:"80",rx:"16",ry:"16",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}),a("line",{x1:"312",y1:"240",x2:"200",y2:"352",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}),a("line",{x1:"312",y1:"352",x2:"200",y2:"240",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}))),It=de("download",a("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},a("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},a("g",{fill:"currentColor","fill-rule":"nonzero"},a("path",{d:"M3.5,13 L12.5,13 C12.7761424,13 13,13.2238576 13,13.5 C13,13.7454599 12.8231248,13.9496084 12.5898756,13.9919443 L12.5,14 L3.5,14 C3.22385763,14 3,13.7761424 3,13.5 C3,13.2545401 3.17687516,13.0503916 3.41012437,13.0080557 L3.5,13 L12.5,13 L3.5,13 Z M7.91012437,1.00805567 L8,1 C8.24545989,1 8.44960837,1.17687516 8.49194433,1.41012437 L8.5,1.5 L8.5,10.292 L11.1819805,7.6109127 C11.3555469,7.43734635 11.6249713,7.4180612 11.8198394,7.55305725 L11.8890873,7.6109127 C12.0626536,7.78447906 12.0819388,8.05390346 11.9469427,8.2487716 L11.8890873,8.31801948 L8.35355339,11.8535534 C8.17998704,12.0271197 7.91056264,12.0464049 7.7156945,11.9114088 L7.64644661,11.8535534 L4.1109127,8.31801948 C3.91565056,8.12275734 3.91565056,7.80617485 4.1109127,7.6109127 C4.28447906,7.43734635 4.55390346,7.4180612 4.7487716,7.55305725 L4.81801948,7.6109127 L7.5,10.292 L7.5,1.5 C7.5,1.25454011 7.67687516,1.05039163 7.91012437,1.00805567 L8,1 L7.91012437,1.00805567 Z"}))))),Ft=de("cancel",a("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},a("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},a("g",{fill:"currentColor","fill-rule":"nonzero"},a("path",{d:"M2.58859116,2.7156945 L2.64644661,2.64644661 C2.82001296,2.47288026 3.08943736,2.45359511 3.2843055,2.58859116 L3.35355339,2.64644661 L8,7.293 L12.6464466,2.64644661 C12.8417088,2.45118446 13.1582912,2.45118446 13.3535534,2.64644661 C13.5488155,2.84170876 13.5488155,3.15829124 13.3535534,3.35355339 L8.707,8 L13.3535534,12.6464466 C13.5271197,12.820013 13.5464049,13.0894374 13.4114088,13.2843055 L13.3535534,13.3535534 C13.179987,13.5271197 12.9105626,13.5464049 12.7156945,13.4114088 L12.6464466,13.3535534 L8,8.707 L3.35355339,13.3535534 C3.15829124,13.5488155 2.84170876,13.5488155 2.64644661,13.3535534 C2.45118446,13.1582912 2.45118446,12.8417088 2.64644661,12.6464466 L7.293,8 L2.64644661,3.35355339 C2.47288026,3.17998704 2.45359511,2.91056264 2.58859116,2.7156945 L2.64644661,2.64644661 L2.58859116,2.7156945 Z"}))))),Ut=de("retry",a("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},a("path",{d:"M320,146s24.36-12-64-12A160,160,0,1,0,416,294",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-miterlimit: 10; stroke-width: 32px;"}),a("polyline",{points:"256 58 336 138 256 218",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}))),oe=Ne("n-upload"),De="__UPLOAD_DRAGGER__",Pt=Z({name:"UploadDragger",[De]:!0,setup(e,{slots:t}){const n=ue(oe,null);return n||pe("upload-dragger","`n-upload-dragger` must be placed inside `n-upload`."),()=>{const{mergedClsPrefixRef:{value:r},mergedDisabledRef:{value:l},maxReachedRef:{value:i}}=n;return a("div",{class:[`${r}-upload-dragger`,(l||i)&&`${r}-upload-dragger--disabled`]},t)}}});var ye=globalThis&&globalThis.__awaiter||function(e,t,n,r){function l(i){return i instanceof n?i:new n(function(d){d(i)})}return new(n||(n=Promise))(function(i,d){function p(o){try{u(r.next(o))}catch(v){d(v)}}function s(o){try{u(r.throw(o))}catch(v){d(v)}}function u(o){o.done?i(o.value):l(o.value).then(p,s)}u((r=r.apply(e,t||[])).next())})};const je=e=>e.includes("image/"),Le=(e="")=>{const t=e.split("/"),r=t[t.length-1].split(/#|\?/)[0];return(/\.[^./\\]*$/.exec(r)||[""])[0]},Te=/(webp|svg|png|gif|jpg|jpeg|jfif|bmp|dpg|ico)$/i,Oe=e=>{if(e.type)return je(e.type);const t=Le(e.name||"");if(Te.test(t))return!0;const n=e.thumbnailUrl||e.url||"",r=Le(n);return!!(/^data:image\//.test(n)||Te.test(r))};function Dt(e){return ye(this,void 0,void 0,function*(){return yield new Promise(t=>{if(!e.type||!je(e.type)){t("");return}t(window.URL.createObjectURL(e))})})}const jt=Me&&window.FileReader&&window.File;function Ot(e){return e.isDirectory}function St(e){return e.isFile}function zt(e,t){return ye(this,void 0,void 0,function*(){const n=[];function r(l){return ye(this,void 0,void 0,function*(){for(const i of l)if(i){if(t&&Ot(i)){const d=i.createReader();try{const p=yield new Promise((s,u)=>{d.readEntries(s,u)});yield r(p)}catch{}}else if(St(i))try{const d=yield new Promise((p,s)=>{i.file(p,s)});n.push({file:d,entry:i,source:"dnd"})}catch{}}})}return yield r(e),n})}function se(e){const{id:t,name:n,percentage:r,status:l,url:i,file:d,thumbnailUrl:p,type:s,fullPath:u,batchId:o}=e;return{id:t,name:n,percentage:r??null,status:l,url:i??null,file:d??null,thumbnailUrl:p??null,type:s??null,fullPath:u??null,batchId:o??null}}function $t(e,t,n){return e=e.toLowerCase(),t=t.toLocaleLowerCase(),n=n.toLocaleLowerCase(),n.split(",").map(l=>l.trim()).filter(Boolean).some(l=>{if(l.startsWith(".")){if(e.endsWith(l))return!0}else if(l.includes("/")){const[i,d]=t.split("/"),[p,s]=l.split("/");if((p==="*"||i&&p&&p===i)&&(s==="*"||d&&s&&s===d))return!0}else return!0;return!1})}const Se=Z({name:"UploadTrigger",props:{abstract:Boolean},setup(e,{slots:t}){const n=ue(oe,null);n||pe("upload-trigger","`n-upload-trigger` must be placed inside `n-upload`.");const{mergedClsPrefixRef:r,mergedDisabledRef:l,maxReachedRef:i,listTypeRef:d,dragOverRef:p,openOpenFileDialog:s,draggerInsideRef:u,handleFileAddition:o,mergedDirectoryDndRef:v,triggerClassRef:M,triggerStyleRef:j}=n,x=I(()=>d.value==="image-card");function V(){l.value||i.value||s()}function D(T){T.preventDefault(),p.value=!0}function O(T){T.preventDefault(),p.value=!0}function E(T){T.preventDefault(),p.value=!1}function X(T){var g;if(T.preventDefault(),!u.value||l.value||i.value){p.value=!1;return}const C=(g=T.dataTransfer)===null||g===void 0?void 0:g.items;C!=null&&C.length?zt(Array.from(C).map(_=>_.webkitGetAsEntry()),v.value).then(_=>{o(_)}).finally(()=>{p.value=!1}):p.value=!1}return()=>{var T;const{value:g}=r;return e.abstract?(T=t.default)===null||T===void 0?void 0:T.call(t,{handleClick:V,handleDrop:X,handleDragOver:D,handleDragEnter:O,handleDragLeave:E}):a("div",{class:[`${g}-upload-trigger`,(l.value||i.value)&&`${g}-upload-trigger--disabled`,x.value&&`${g}-upload-trigger--image-card`,M.value],style:j.value,onClick:V,onDrop:X,onDragover:D,onDragenter:O,onDragleave:E},x.value?a(Pt,null,{default:()=>Ee(t.default,()=>[a(Q,{clsPrefix:g},{default:()=>a(qe,null)})])}):t)}}}),At=Z({name:"UploadProgress",props:{show:Boolean,percentage:{type:Number,required:!0},status:{type:String,required:!0}},setup(){return{mergedTheme:ue(oe).mergedThemeRef}},render(){return a(Ie,null,{default:()=>this.show?a($e,{type:"line",showIndicator:!1,percentage:this.percentage,status:this.status,height:2,theme:this.mergedTheme.peers.Progress,themeOverrides:this.mergedTheme.peerOverrides.Progress}):null})}}),Nt=a("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 28 28"},a("g",{fill:"none"},a("path",{d:"M21.75 3A3.25 3.25 0 0 1 25 6.25v15.5A3.25 3.25 0 0 1 21.75 25H6.25A3.25 3.25 0 0 1 3 21.75V6.25A3.25 3.25 0 0 1 6.25 3h15.5zm.583 20.4l-7.807-7.68a.75.75 0 0 0-.968-.07l-.084.07l-7.808 7.68c.183.065.38.1.584.1h15.5c.204 0 .4-.035.583-.1l-7.807-7.68l7.807 7.68zM21.75 4.5H6.25A1.75 1.75 0 0 0 4.5 6.25v15.5c0 .208.036.408.103.593l7.82-7.692a2.25 2.25 0 0 1 3.026-.117l.129.117l7.82 7.692c.066-.185.102-.385.102-.593V6.25a1.75 1.75 0 0 0-1.75-1.75zm-3.25 3a2.5 2.5 0 1 1 0 5a2.5 2.5 0 0 1 0-5zm0 1.5a1 1 0 1 0 0 2a1 1 0 0 0 0-2z",fill:"currentColor"}))),Mt=a("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 28 28"},a("g",{fill:"none"},a("path",{d:"M6.4 2A2.4 2.4 0 0 0 4 4.4v19.2A2.4 2.4 0 0 0 6.4 26h15.2a2.4 2.4 0 0 0 2.4-2.4V11.578c0-.729-.29-1.428-.805-1.944l-6.931-6.931A2.4 2.4 0 0 0 14.567 2H6.4zm-.9 2.4a.9.9 0 0 1 .9-.9H14V10a2 2 0 0 0 2 2h6.5v11.6a.9.9 0 0 1-.9.9H6.4a.9.9 0 0 1-.9-.9V4.4zm16.44 6.1H16a.5.5 0 0 1-.5-.5V4.06l6.44 6.44z",fill:"currentColor"})));var Et=globalThis&&globalThis.__awaiter||function(e,t,n,r){function l(i){return i instanceof n?i:new n(function(d){d(i)})}return new(n||(n=Promise))(function(i,d){function p(o){try{u(r.next(o))}catch(v){d(v)}}function s(o){try{u(r.throw(o))}catch(v){d(v)}}function u(o){o.done?i(o.value):l(o.value).then(p,s)}u((r=r.apply(e,t||[])).next())})};const fe={paddingMedium:"0 3px",heightMedium:"24px",iconSizeMedium:"18px"},qt=Z({name:"UploadFile",props:{clsPrefix:{type:String,required:!0},file:{type:Object,required:!0},listType:{type:String,required:!0}},setup(e){const t=ue(oe),n=z(null),r=z(""),l=I(()=>{const{file:g}=e;return g.status==="finished"?"success":g.status==="error"?"error":"info"}),i=I(()=>{const{file:g}=e;if(g.status==="error")return"error"}),d=I(()=>{const{file:g}=e;return g.status==="uploading"}),p=I(()=>{if(!t.showCancelButtonRef.value)return!1;const{file:g}=e;return["uploading","pending","error"].includes(g.status)}),s=I(()=>{if(!t.showRemoveButtonRef.value)return!1;const{file:g}=e;return["finished"].includes(g.status)}),u=I(()=>{if(!t.showDownloadButtonRef.value)return!1;const{file:g}=e;return["finished"].includes(g.status)}),o=I(()=>{if(!t.showRetryButtonRef.value)return!1;const{file:g}=e;return["error"].includes(g.status)}),v=He(()=>r.value||e.file.thumbnailUrl||e.file.url),M=I(()=>{if(!t.showPreviewButtonRef.value)return!1;const{file:{status:g},listType:C}=e;return["finished"].includes(g)&&v.value&&C==="image-card"});function j(){t.submit(e.file.id)}function x(g){g.preventDefault();const{file:C}=e;["finished","pending","error"].includes(C.status)?D(C):["uploading"].includes(C.status)?E(C):Ze("upload","The button clicked type is unknown.")}function V(g){g.preventDefault(),O(e.file)}function D(g){const{xhrMap:C,doChange:_,onRemoveRef:{value:re},mergedFileListRef:{value:c}}=t;Promise.resolve(re?re({file:Object.assign({},g),fileList:c}):!0).then(L=>{if(L===!1)return;const B=Object.assign({},g,{status:"removed"});C.delete(g.id),_(B,void 0,{remove:!0})})}function O(g){const{onDownloadRef:{value:C}}=t;Promise.resolve(C?C(Object.assign({},g)):!0).then(_=>{_!==!1&&Ke(g.url,g.name)})}function E(g){const{xhrMap:C}=t,_=C.get(g.id);_==null||_.abort(),D(Object.assign({},g))}function X(){const{onPreviewRef:{value:g}}=t;if(g)g(e.file);else if(e.listType==="image-card"){const{value:C}=n;if(!C)return;C.click()}}const T=()=>Et(this,void 0,void 0,function*(){const{listType:g}=e;g!=="image"&&g!=="image-card"||t.shouldUseThumbnailUrlRef.value(e.file)&&(r.value=yield t.getFileThumbnailUrlResolver(e.file))});return Ve(()=>{T()}),{mergedTheme:t.mergedThemeRef,progressStatus:l,buttonType:i,showProgress:d,disabled:t.mergedDisabledRef,showCancelButton:p,showRemoveButton:s,showDownloadButton:u,showRetryButton:o,showPreviewButton:M,mergedThumbnailUrl:v,shouldUseThumbnailUrl:t.shouldUseThumbnailUrlRef,renderIcon:t.renderIconRef,imageRef:n,handleRemoveOrCancelClick:x,handleDownloadClick:V,handleRetryClick:j,handlePreviewClick:X}},render(){const{clsPrefix:e,mergedTheme:t,listType:n,file:r,renderIcon:l}=this;let i;const d=n==="image";d||n==="image-card"?i=!this.shouldUseThumbnailUrl(r)||!this.mergedThumbnailUrl?a("span",{class:`${e}-upload-file-info__thumbnail`},l?l(r):Oe(r)?a(Q,{clsPrefix:e},{default:()=>Nt}):a(Q,{clsPrefix:e},{default:()=>Mt})):a("a",{rel:"noopener noreferer",target:"_blank",href:r.url||void 0,class:`${e}-upload-file-info__thumbnail`,onClick:this.handlePreviewClick},n==="image-card"?a(Xe,{src:this.mergedThumbnailUrl||void 0,previewSrc:r.url||void 0,alt:r.name,ref:"imageRef"}):a("img",{src:this.mergedThumbnailUrl||void 0,alt:r.name})):i=a("span",{class:`${e}-upload-file-info__thumbnail`},l?l(r):a(Q,{clsPrefix:e},{default:()=>a(Tt,null)}));const s=a(At,{show:this.showProgress,percentage:r.percentage||0,status:this.progressStatus}),u=n==="text"||n==="image";return a("div",{class:[`${e}-upload-file`,`${e}-upload-file--${this.progressStatus}-status`,r.url&&r.status!=="error"&&n!=="image-card"&&`${e}-upload-file--with-url`,`${e}-upload-file--${n}-type`]},a("div",{class:`${e}-upload-file-info`},i,a("div",{class:`${e}-upload-file-info__name`},u&&(r.url&&r.status!=="error"?a("a",{rel:"noopener noreferer",target:"_blank",href:r.url||void 0,onClick:this.handlePreviewClick},r.name):a("span",{onClick:this.handlePreviewClick},r.name)),d&&s),a("div",{class:[`${e}-upload-file-info__action`,`${e}-upload-file-info__action--${n}-type`]},this.showPreviewButton?a(W,{key:"preview",quaternary:!0,type:this.buttonType,onClick:this.handlePreviewClick,theme:t.peers.Button,themeOverrides:t.peerOverrides.Button,builtinThemeOverrides:fe},{icon:()=>a(Q,{clsPrefix:e},{default:()=>a(Ge,null)})}):null,(this.showRemoveButton||this.showCancelButton)&&!this.disabled&&a(W,{key:"cancelOrTrash",theme:t.peers.Button,themeOverrides:t.peerOverrides.Button,quaternary:!0,builtinThemeOverrides:fe,type:this.buttonType,onClick:this.handleRemoveOrCancelClick},{icon:()=>a(We,null,{default:()=>this.showRemoveButton?a(Q,{clsPrefix:e,key:"trash"},{default:()=>a(Bt,null)}):a(Q,{clsPrefix:e,key:"cancel"},{default:()=>a(Ft,null)})})}),this.showRetryButton&&!this.disabled&&a(W,{key:"retry",quaternary:!0,type:this.buttonType,onClick:this.handleRetryClick,theme:t.peers.Button,themeOverrides:t.peerOverrides.Button,builtinThemeOverrides:fe},{icon:()=>a(Q,{clsPrefix:e},{default:()=>a(Ut,null)})}),this.showDownloadButton?a(W,{key:"download",quaternary:!0,type:this.buttonType,onClick:this.handleDownloadClick,theme:t.peers.Button,themeOverrides:t.peerOverrides.Button,builtinThemeOverrides:fe},{icon:()=>a(Q,{clsPrefix:e},{default:()=>a(It,null)})}):null)),!d&&s)}}),Ht=Z({name:"UploadFileList",setup(e,{slots:t}){const n=ue(oe,null);n||pe("upload-file-list","`n-upload-file-list` must be placed inside `n-upload`.");const{abstractRef:r,mergedClsPrefixRef:l,listTypeRef:i,mergedFileListRef:d,fileListClassRef:p,fileListStyleRef:s,cssVarsRef:u,themeClassRef:o,maxReachedRef:v,showTriggerRef:M,imageGroupPropsRef:j}=n,x=I(()=>i.value==="image-card"),V=()=>d.value.map(O=>a(qt,{clsPrefix:l.value,key:O.id,file:O,listType:i.value})),D=()=>x.value?a(Qe,Object.assign({},j.value),{default:V}):a(Ie,{group:!0},{default:V});return()=>{const{value:O}=l,{value:E}=r;return a("div",{class:[`${O}-upload-file-list`,x.value&&`${O}-upload-file-list--grid`,E?o==null?void 0:o.value:void 0,p.value],style:[E&&u?u.value:"",s.value]},D(),M.value&&!v.value&&x.value&&a(Se,null,t))}}}),Vt=$([k("upload","width: 100%;",[A("dragger-inside",[k("upload-trigger",`
 display: block;
 `)]),A("drag-over",[k("upload-dragger",`
 border: var(--n-dragger-border-hover);
 `)])]),k("upload-dragger",`
 cursor: pointer;
 box-sizing: border-box;
 width: 100%;
 text-align: center;
 border-radius: var(--n-border-radius);
 padding: 24px;
 opacity: 1;
 transition:
 opacity .3s var(--n-bezier),
 border-color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 background-color: var(--n-dragger-color);
 border: var(--n-dragger-border);
 `,[$("&:hover",`
 border: var(--n-dragger-border-hover);
 `),A("disabled",`
 cursor: not-allowed;
 `)]),k("upload-trigger",`
 display: inline-block;
 box-sizing: border-box;
 opacity: 1;
 transition: opacity .3s var(--n-bezier);
 `,[$("+",[k("upload-file-list","margin-top: 8px;")]),A("disabled",`
 opacity: var(--n-item-disabled-opacity);
 cursor: not-allowed;
 `),A("image-card",`
 width: 96px;
 height: 96px;
 `,[k("base-icon",`
 font-size: 24px;
 `),k("upload-dragger",`
 padding: 0;
 height: 100%;
 width: 100%;
 display: flex;
 align-items: center;
 justify-content: center;
 `)])]),k("upload-file-list",`
 line-height: var(--n-line-height);
 opacity: 1;
 transition: opacity .3s var(--n-bezier);
 `,[$("a, img","outline: none;"),A("disabled",`
 opacity: var(--n-item-disabled-opacity);
 cursor: not-allowed;
 `,[k("upload-file","cursor: not-allowed;")]),A("grid",`
 display: grid;
 grid-template-columns: repeat(auto-fill, 96px);
 grid-gap: 8px;
 margin-top: 0;
 `),k("upload-file",`
 display: block;
 box-sizing: border-box;
 cursor: default;
 padding: 0px 12px 0 6px;
 transition: background-color .3s var(--n-bezier);
 border-radius: var(--n-border-radius);
 `,[we(),k("progress",[we({foldPadding:!0})]),$("&:hover",`
 background-color: var(--n-item-color-hover);
 `,[k("upload-file-info",[G("action",`
 opacity: 1;
 `)])]),A("image-type",`
 border-radius: var(--n-border-radius);
 text-decoration: underline;
 text-decoration-color: #0000;
 `,[k("upload-file-info",`
 padding-top: 0px;
 padding-bottom: 0px;
 width: 100%;
 height: 100%;
 display: flex;
 justify-content: space-between;
 align-items: center;
 padding: 6px 0;
 `,[k("progress",`
 padding: 2px 0;
 margin-bottom: 0;
 `),G("name",`
 padding: 0 8px;
 `),G("thumbnail",`
 width: 32px;
 height: 32px;
 font-size: 28px;
 display: flex;
 justify-content: center;
 align-items: center;
 `,[$("img",`
 width: 100%;
 `)])])]),A("text-type",[k("progress",`
 box-sizing: border-box;
 padding-bottom: 6px;
 margin-bottom: 6px;
 `)]),A("image-card-type",`
 position: relative;
 width: 96px;
 height: 96px;
 border: var(--n-item-border-image-card);
 border-radius: var(--n-border-radius);
 padding: 0;
 display: flex;
 align-items: center;
 justify-content: center;
 transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier);
 border-radius: var(--n-border-radius);
 overflow: hidden;
 `,[k("progress",`
 position: absolute;
 left: 8px;
 bottom: 8px;
 right: 8px;
 width: unset;
 `),k("upload-file-info",`
 padding: 0;
 width: 100%;
 height: 100%;
 `,[G("thumbnail",`
 width: 100%;
 height: 100%;
 display: flex;
 flex-direction: column;
 align-items: center;
 justify-content: center;
 font-size: 36px;
 `,[$("img",`
 width: 100%;
 `)])]),$("&::before",`
 position: absolute;
 z-index: 1;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 border-radius: inherit;
 opacity: 0;
 transition: opacity .2s var(--n-bezier);
 content: "";
 `),$("&:hover",[$("&::before","opacity: 1;"),k("upload-file-info",[G("thumbnail","opacity: .12;")])])]),A("error-status",[$("&:hover",`
 background-color: var(--n-item-color-hover-error);
 `),k("upload-file-info",[G("name","color: var(--n-item-text-color-error);"),G("thumbnail","color: var(--n-item-text-color-error);")]),A("image-card-type",`
 border: var(--n-item-border-image-card-error);
 `)]),A("with-url",`
 cursor: pointer;
 `,[k("upload-file-info",[G("name",`
 color: var(--n-item-text-color-success);
 text-decoration-color: var(--n-item-text-color-success);
 `,[$("a",`
 text-decoration: underline;
 `)])])]),k("upload-file-info",`
 position: relative;
 padding-top: 6px;
 padding-bottom: 6px;
 display: flex;
 flex-wrap: nowrap;
 `,[G("thumbnail",`
 font-size: 18px;
 opacity: 1;
 transition: opacity .2s var(--n-bezier);
 color: var(--n-item-icon-color);
 `,[k("base-icon",`
 margin-right: 2px;
 vertical-align: middle;
 transition: color .3s var(--n-bezier);
 `)]),G("action",`
 padding-top: inherit;
 padding-bottom: inherit;
 position: absolute;
 right: 0;
 top: 0;
 bottom: 0;
 width: 80px;
 display: flex;
 align-items: center;
 transition: opacity .2s var(--n-bezier);
 justify-content: flex-end;
 opacity: 0;
 `,[k("button",[$("&:not(:last-child)",{marginRight:"4px"}),k("base-icon",[$("svg",[Je()])])]),A("image-type",`
 position: relative;
 max-width: 80px;
 width: auto;
 `),A("image-card-type",`
 z-index: 2;
 position: absolute;
 width: 100%;
 height: 100%;
 left: 0;
 right: 0;
 bottom: 0;
 top: 0;
 display: flex;
 justify-content: center;
 align-items: center;
 `)]),G("name",`
 color: var(--n-item-text-color);
 flex: 1;
 display: flex;
 justify-content: center;
 text-overflow: ellipsis;
 overflow: hidden;
 flex-direction: column;
 text-decoration-color: #0000;
 font-size: var(--n-font-size);
 transition:
 color .3s var(--n-bezier),
 text-decoration-color .3s var(--n-bezier); 
 `,[$("a",`
 color: inherit;
 text-decoration: underline;
 `)])])])]),k("upload-file-input",`
 display: none;
 width: 0;
 height: 0;
 opacity: 0;
 `)]);var Be=globalThis&&globalThis.__awaiter||function(e,t,n,r){function l(i){return i instanceof n?i:new n(function(d){d(i)})}return new(n||(n=Promise))(function(i,d){function p(o){try{u(r.next(o))}catch(v){d(v)}}function s(o){try{u(r.throw(o))}catch(v){d(v)}}function u(o){o.done?i(o.value):l(o.value).then(p,s)}u((r=r.apply(e,t||[])).next())})};function Xt(e,t,n){const{doChange:r,xhrMap:l}=e;let i=0;function d(s){var u;let o=Object.assign({},t,{status:"error",percentage:i});l.delete(t.id),o=se(((u=e.onError)===null||u===void 0?void 0:u.call(e,{file:o,event:s}))||o),r(o,s)}function p(s){var u;if(e.isErrorState){if(e.isErrorState(n)){d(s);return}}else if(n.status<200||n.status>=300){d(s);return}let o=Object.assign({},t,{status:"finished",percentage:i});l.delete(t.id),o=se(((u=e.onFinish)===null||u===void 0?void 0:u.call(e,{file:o,event:s}))||o),r(o,s)}return{handleXHRLoad:p,handleXHRError:d,handleXHRAbort(s){const u=Object.assign({},t,{status:"removed",file:null,percentage:i});l.delete(t.id),r(u,s)},handleXHRProgress(s){const u=Object.assign({},t,{status:"uploading"});if(s.lengthComputable){const o=Math.ceil(s.loaded/s.total*100);u.percentage=o,i=o}r(u,s)}}}function Gt(e){const{inst:t,file:n,data:r,headers:l,withCredentials:i,action:d,customRequest:p}=e,{doChange:s}=e.inst;let u=0;p({file:n,data:r,headers:l,withCredentials:i,action:d,onProgress(o){const v=Object.assign({},n,{status:"uploading"}),M=o.percent;v.percentage=M,u=M,s(v)},onFinish(){var o;let v=Object.assign({},n,{status:"finished",percentage:u});v=se(((o=t.onFinish)===null||o===void 0?void 0:o.call(t,{file:v}))||v),s(v)},onError(){var o;let v=Object.assign({},n,{status:"error",percentage:u});v=se(((o=t.onError)===null||o===void 0?void 0:o.call(t,{file:v}))||v),s(v)}})}function Wt(e,t,n){const r=Xt(e,t,n);n.onabort=r.handleXHRAbort,n.onerror=r.handleXHRError,n.onload=r.handleXHRLoad,n.upload&&(n.upload.onprogress=r.handleXHRProgress)}function ze(e,t){return typeof e=="function"?e({file:t}):e||{}}function Zt(e,t,n){const r=ze(t,n);r&&Object.keys(r).forEach(l=>{e.setRequestHeader(l,r[l])})}function Kt(e,t,n){const r=ze(t,n);r&&Object.keys(r).forEach(l=>{e.append(l,r[l])})}function Qt(e,t,n,{method:r,action:l,withCredentials:i,responseType:d,headers:p,data:s}){const u=new XMLHttpRequest;u.responseType=d,e.xhrMap.set(n.id,u),u.withCredentials=i;const o=new FormData;if(Kt(o,s,n),n.file!==null&&o.append(t,n.file),Wt(e,n,u),l!==void 0){u.open(r.toUpperCase(),l),Zt(u,p,n),u.send(o);const v=Object.assign({},n,{status:"uploading"});e.doChange(v)}}const Jt=Object.assign(Object.assign({},Fe.props),{name:{type:String,default:"file"},accept:String,action:String,customRequest:Function,directory:Boolean,directoryDnd:{type:Boolean,default:void 0},method:{type:String,default:"POST"},multiple:Boolean,showFileList:{type:Boolean,default:!0},data:[Object,Function],headers:[Object,Function],withCredentials:Boolean,responseType:{type:String,default:""},disabled:{type:Boolean,default:void 0},onChange:Function,onRemove:Function,onFinish:Function,onError:Function,onBeforeUpload:Function,isErrorState:Function,onDownload:Function,defaultUpload:{type:Boolean,default:!0},fileList:Array,"onUpdate:fileList":[Function,Array],onUpdateFileList:[Function,Array],fileListClass:String,fileListStyle:[String,Object],defaultFileList:{type:Array,default:()=>[]},showCancelButton:{type:Boolean,default:!0},showRemoveButton:{type:Boolean,default:!0},showDownloadButton:Boolean,showRetryButton:{type:Boolean,default:!0},showPreviewButton:{type:Boolean,default:!0},listType:{type:String,default:"text"},onPreview:Function,shouldUseThumbnailUrl:{type:Function,default:e=>jt?Oe(e):!1},createThumbnailUrl:Function,abstract:Boolean,max:Number,showTrigger:{type:Boolean,default:!0},imageGroupProps:Object,inputProps:Object,triggerClass:String,triggerStyle:[String,Object],renderIcon:Function}),Yt=Z({name:"Upload",props:Jt,setup(e){e.abstract&&e.listType==="image-card"&&pe("upload","when the list-type is image-card, abstract is not supported.");const{mergedClsPrefixRef:t,inlineThemeDisabled:n}=Ye(e),r=Fe("Upload","-upload",Vt,ot,e,t),l=et(e),i=I(()=>{const{max:c}=e;return c!==void 0?j.value.length>=c:!1}),d=z(e.defaultFileList),p=P(e,"fileList"),s=z(null),u={value:!1},o=z(!1),v=new Map,M=tt(p,d),j=I(()=>M.value.map(se));function x(){var c;(c=s.value)===null||c===void 0||c.click()}function V(c){const L=c.target;E(L.files?Array.from(L.files).map(B=>({file:B,entry:null,source:"input"})):null,c),L.value=""}function D(c){const{"onUpdate:fileList":L,onUpdateFileList:B}=e;L&&Re(L,c),B&&Re(B,c),d.value=c}const O=I(()=>e.multiple||e.directory);function E(c,L){if(!c||c.length===0)return;const{onBeforeUpload:B}=e;c=O.value?c:[c[0]];const{max:H,accept:N}=e;c=c.filter(({file:F,source:U})=>U==="dnd"&&(N!=null&&N.trim())?$t(F.name,F.type,N):!0),H&&(c=c.slice(0,H-j.value.length));const S=xe();Promise.all(c.map(({file:F,entry:U})=>Be(this,void 0,void 0,function*(){var y;const h={id:xe(),batchId:S,name:F.name,status:"pending",percentage:0,file:F,url:null,type:F.type,thumbnailUrl:null,fullPath:(y=U==null?void 0:U.fullPath)!==null&&y!==void 0?y:`/${F.webkitRelativePath||F.name}`};return!B||(yield B({file:h,fileList:j.value}))!==!1?h:null}))).then(F=>Be(this,void 0,void 0,function*(){let U=Promise.resolve();F.forEach(y=>{U=U.then(lt).then(()=>{y&&T(y,L,{append:!0})})}),yield U})).then(()=>{e.defaultUpload&&X()})}function X(c){const{method:L,action:B,withCredentials:H,headers:N,data:S,name:F}=e,U=c!==void 0?j.value.filter(h=>h.id===c):j.value,y=c!==void 0;U.forEach(h=>{const{status:f}=h;(f==="pending"||f==="error"&&y)&&(e.customRequest?Gt({inst:{doChange:T,xhrMap:v,onFinish:e.onFinish,onError:e.onError},file:h,action:B,withCredentials:H,headers:N,data:S,customRequest:e.customRequest}):Qt({doChange:T,xhrMap:v,onFinish:e.onFinish,onError:e.onError,isErrorState:e.isErrorState},F,h,{method:L,action:B,withCredentials:H,responseType:e.responseType,headers:N,data:S}))})}const T=(c,L,B={append:!1,remove:!1})=>{const{append:H,remove:N}=B,S=Array.from(j.value),F=S.findIndex(U=>U.id===c.id);if(H||N||~F){H?S.push(c):N?S.splice(F,1):S.splice(F,1,c);const{onChange:U}=e;U&&U({file:c,fileList:S,event:L}),D(S)}};function g(c){var L;if(c.thumbnailUrl)return c.thumbnailUrl;const{createThumbnailUrl:B}=e;return B?(L=B(c.file,c))!==null&&L!==void 0?L:c.url||"":c.url?c.url:c.file?Dt(c.file):""}const C=I(()=>{const{common:{cubicBezierEaseInOut:c},self:{draggerColor:L,draggerBorder:B,draggerBorderHover:H,itemColorHover:N,itemColorHoverError:S,itemTextColorError:F,itemTextColorSuccess:U,itemTextColor:y,itemIconColor:h,itemDisabledOpacity:f,lineHeight:q,borderRadius:ee,fontSize:te,itemBorderImageCardError:ge,itemBorderImageCard:he}}=r.value;return{"--n-bezier":c,"--n-border-radius":ee,"--n-dragger-border":B,"--n-dragger-border-hover":H,"--n-dragger-color":L,"--n-font-size":te,"--n-item-color-hover":N,"--n-item-color-hover-error":S,"--n-item-disabled-opacity":f,"--n-item-icon-color":h,"--n-item-text-color":y,"--n-item-text-color-error":F,"--n-item-text-color-success":U,"--n-line-height":q,"--n-item-border-image-card-error":ge,"--n-item-border-image-card":he}}),_=n?nt("upload",void 0,C,e):void 0;rt(oe,{mergedClsPrefixRef:t,mergedThemeRef:r,showCancelButtonRef:P(e,"showCancelButton"),showDownloadButtonRef:P(e,"showDownloadButton"),showRemoveButtonRef:P(e,"showRemoveButton"),showRetryButtonRef:P(e,"showRetryButton"),onRemoveRef:P(e,"onRemove"),onDownloadRef:P(e,"onDownload"),mergedFileListRef:j,triggerClassRef:P(e,"triggerClass"),triggerStyleRef:P(e,"triggerStyle"),shouldUseThumbnailUrlRef:P(e,"shouldUseThumbnailUrl"),renderIconRef:P(e,"renderIcon"),xhrMap:v,submit:X,doChange:T,showPreviewButtonRef:P(e,"showPreviewButton"),onPreviewRef:P(e,"onPreview"),getFileThumbnailUrlResolver:g,listTypeRef:P(e,"listType"),dragOverRef:o,openOpenFileDialog:x,draggerInsideRef:u,handleFileAddition:E,mergedDisabledRef:l.mergedDisabledRef,maxReachedRef:i,fileListClassRef:P(e,"fileListClass"),fileListStyleRef:P(e,"fileListStyle"),abstractRef:P(e,"abstract"),acceptRef:P(e,"accept"),cssVarsRef:n?void 0:C,themeClassRef:_==null?void 0:_.themeClass,onRender:_==null?void 0:_.onRender,showTriggerRef:P(e,"showTrigger"),imageGroupPropsRef:P(e,"imageGroupProps"),mergedDirectoryDndRef:I(()=>{var c;return(c=e.directoryDnd)!==null&&c!==void 0?c:e.directory})});const re={clear:()=>{d.value=[]},submit:X,openOpenFileDialog:x};return Object.assign({mergedClsPrefix:t,draggerInsideRef:u,inputElRef:s,mergedTheme:r,dragOver:o,mergedMultiple:O,cssVars:n?void 0:C,themeClass:_==null?void 0:_.themeClass,onRender:_==null?void 0:_.onRender,handleFileInputChange:V},re)},render(){var e,t;const{draggerInsideRef:n,mergedClsPrefix:r,$slots:l,directory:i,onRender:d}=this;if(l.default&&!this.abstract){const s=l.default()[0];!((e=s==null?void 0:s.type)===null||e===void 0)&&e[De]&&(n.value=!0)}const p=a("input",Object.assign({},this.inputProps,{ref:"inputElRef",type:"file",class:`${r}-upload-file-input`,accept:this.accept,multiple:this.mergedMultiple,onChange:this.handleFileInputChange,webkitdirectory:i||void 0,directory:i||void 0}));return this.abstract?a(be,null,(t=l.default)===null||t===void 0?void 0:t.call(l),a(at,{to:"body"},p)):(d==null||d(),a("div",{class:[`${r}-upload`,n.value&&`${r}-upload--dragger-inside`,this.dragOver&&`${r}-upload--drag-over`,this.themeClass],style:this.cssVars},p,this.showTrigger&&this.listType!=="image-card"&&a(Se,null,l),this.showFileList&&a(Ht,null,l)))}}),en={class:"m-auto flex h-14 max-w-screen-4xl items-center justify-between px-4"},tn={class:"flex min-w-0 flex-1 items-center space-x-2 overflow-hidden pr-2"},nn=R("h2",{class:"text-base font-bold"}," 我的自定义工作台 ",-1),rn=R("div",{class:"flex items-center space-x-2"},null,-1),an=Z({__name:"header",setup(e){const t=Ue();return(n,r)=>(J(),ae("div",en,[R("div",tn,[R("button",{onClick:r[0]||(r[0]=l=>m(t).go(-1))},[b(m(ne),{class:"text-xl",icon:"ri:arrow-left-s-line"})]),nn]),rn]))}}),on={class:"w-full flex justify-center"},ln={class:"p-6 max-w-screen-4xl px-4 w-full"},sn={class:"flex flex-col space-y-3 justify-between sm:flex-row sm:space-y-0 sm:justify-end"},dn=R("span",{class:"font-bold ml-2"},"关键词过滤",-1),un={class:"sm:w-full md:w-[400px] sm:mb-3 2xl:w-[1350px]"},cn=R("br",null,null,-1),fn={class:"mt-10 grid grid-cols-1 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-4 gap-5"},pn=["onClick"],gn={class:"w-full h-16 flex items-center mb-3"},hn={class:"w-14 h-14 flex justify-center items-center rounded-md shadow-md mr-5 border border-[#00000014]"},mn=["src"],vn={class:"text-base font-bold mb-1 text-base text-[#333] dark:text-[#ffffff85]"},bn={class:"w-full text-[#999999] text-xs min-h-[40px]"},yn={class:"w-full flex justify-between mt-3"},wn={class:"border-2 border-black p-5 bg-white rounded-lg dark:bg-slate-800"},xn={class:"font-bold text-base"},Rn={class:"pt-5 mt-6"},Cn=R("p",null,"Tips: 请知悉 ",-1),_n=R("p",null,"选择共享提交之后审核状态将无法编辑应用",-1),kn=R("p",null,"审核通过的应用将会在应用广场公开展示",-1),Ln=R("p",null,"管理审核通过后将会赠送一定的站内额度奖励用户",-1),Tn=R("p",null,"一旦提交处于审核中、您将不能再编辑此应用",-1),Bn=Z({__name:"main",setup(e){const t=it(),n=z(""),r=z(!1),l=z(!1),i=z([]),d=z(null),p=z(0),s=z(!1),u=I(()=>p.value===0?"创建我的个人应用":"更新我的个人应用"),o=I(()=>p.value===0?"创建专属应用":"更新个人应用"),v=I(()=>n.value?t.mineApps.filter(y=>y.appName.includes(n.value)):t.mineApps),M=z("https://ai.liudafang.com/api/upload/file"),j=()=>({catId:null,name:null,preset:null,des:null,demoData:"",coverImg:"",public:!1}),x=z(j()),V={catId:[{required:!0,message:"请选择分类"}],name:[{required:!0,message:"请输入应用名称",trigger:"blur"},{min:2,max:30,message:"长度应为2到10个字符之间",trigger:"blur"}],preset:[{required:!0,message:"请输入预设prompt",trigger:"blur"},{min:6,max:1200,message:"长度应为6到1200个字符之间",trigger:"blur"}],des:[{required:!0,message:"请输入简短的应用描述",trigger:"blur"},{max:50,message:"长度应为0到50个字符之间",trigger:"blur"}],demoData:[{required:!0,message:"请输入示例数据、按回车换行表示新增一条",trigger:"blur"},{max:100,message:"长度应为0到100个字符之间",trigger:"blur"}],coverImg:[{required:!0,message:"请上传应用Logo",trigger:"change"}],public:[{required:!0,message:"请选择是否公开"}]};Pe();const D=st(),O=Ue(),E=z([]),X=z(null);function T(y){n.value=y}async function g(y){const h=await mt(),{modelMaps:f}=h.data;if(!f[1])return D.warning("管理员未配置特定应用模型、请联系管理员配置~");O.push({path:"/chat",query:{appId:y.appId}})}async function C(y){y.loading=!0;try{const h=await vt({appId:y.appId});D.success(h.data),await t.queryMineApps(),y.loading=!1}catch{y.loading=!1}}async function _(){const y=await xt();E.value=y.data.rows}async function re(y){const h=await bt({id:y.appId});D.success(h.data),t.queryMineApps()}async function c(y){if(!y.length)X.value=null;else{const h=y[0].file;X.value=h;const f=new FormData;f.append("file",h);const q=await yt.post(M.value,f,{headers:{"Content-Type":"multipart/form-data"}});q.data.data?x.value.coverImg=q.data.data:D.error("上传图片失败、请检查后再试试吧！")}}function L({file:y,fileList:h}){return new Promise((f,q)=>{const{size:ee,type:te}=y.file;if(te!=="image/png"&&te!=="image/jpg"&&te!=="image/jpeg")return D.error("只能上传png/jpg/jpeg格式的图片"),f(!1);if(ee>300*1024)return D.error("图片大小不能超过300k"),f(!1);f(!0)})}dt(()=>{!v.value.length&&t.queryMineApps()});function B(){l.value=!0,_()}function H(){}function N(){S()}function S(){p.value=0,s.value=!1,x.value=j()}async function F(y){await _();const{catId:h,appName:f,preset:q,appDes:ee,demoData:te,coverImg:ge,public:he}=y;Object.assign(x.value,{catId:h,name:f,preset:q,des:ee,demoData:te,coverImg:ge,public:he}),p.value=y.appId,l.value=!0,s.value=y.public}function U(){var y;(y=d.value)==null||y.validate(async h=>{if(!h){const f=x.value;p.value&&(f.appId=p.value);const q=await wt(f),ee=p.value?"个人应用修改完成！":"个人应用创建完成！";q.success&&D.success(ee),t.queryMineApps(),S(),l.value=!1}})}return(y,h)=>(J(),ae(be,null,[R("div",on,[R("div",ln,[R("div",sn,[b(m(Ce),null,{default:w(()=>[b(m(W),{class:"create",onClick:B},{icon:w(()=>[b(m(ne),{icon:"gridicons:create"})]),default:w(()=>[K(" 创建自定义应用 ")]),_:1}),b(m(W),{class:"create",type:"primary",onClick:h[0]||(h[0]=f=>m(O).push("/app-store"))},{icon:w(()=>[b(m(ne),{icon:"ri:add-line"})]),default:w(()=>[K(" 前往广场添加应用 ")]),_:1})]),_:1})]),dn,R("div",un,[cn,b(m(le),{modelValue:n.value,"onUpdate:modelValue":h[1]||(h[1]=f=>n.value=f),class:"search",type:"text",placeholder:`您一共收录了${m(v).length}个应用(关键词过滤)`,onInput:T},null,8,["modelValue","placeholder"])]),R("div",fn,[(J(!0),ae(be,null,ut(m(v),f=>(J(),ae("div",{key:f.id,class:"card relative custom-card cursor-pointer border border-[#e0e0e0] dark:border-neutral-800 p-4 pt-2 border rounded-md flex flex-col justify-center items-center hover:bg-neutral-100 dark:hover:bg-[#24272e] select-none",onClick:q=>g(f)},[R("div",gn,[R("span",hn,[R("img",{src:f.coverImg,class:"w-8 h-8 mb-1",alt:""},null,8,mn)]),R("span",vn,ce(f.appName),1)]),R("p",bn,ce(f.appDes),1),R("div",yn,[f.appRole==="system"||f.public?(J(),me(m(ke),{key:0,placement:"bottom",onPositiveClick:ie(q=>C(f),["stop"])},{trigger:w(()=>[b(m(W),{size:"tiny",ghost:"",loading:f.loading,onClick:h[2]||(h[2]=ie(()=>{},["stop"]))},{icon:w(()=>[b(m(ne),{icon:"clarity:favorite-line",class:"text-base"})]),default:w(()=>[K(" 取消收藏 ")]),_:2},1032,["loading"])]),default:w(()=>[K(" 确认取消收藏该应用吗？ ")]),_:2},1032,["onPositiveClick"])):ve("",!0),b(m(Ce),null,{default:w(()=>[f.appRole==="user"&&!f.public?(J(),me(m(ke),{key:0,placement:"bottom",onPositiveClick:ie(q=>re(f),["stop"])},{trigger:w(()=>[b(m(W),{size:"medium",ghost:"",loading:f.loading,class:"create",onClick:h[3]||(h[3]=ie(()=>{},["stop"]))},{icon:w(()=>[b(m(ne),{icon:"mdi-light:delete",class:"text-base"})]),default:w(()=>[K(" 从工作台移除 ")]),_:2},1032,["loading"])]),default:w(()=>[K(" 确认移除创建的应用吗？ ")]),_:2},1032,["onPositiveClick"])):ve("",!0),f.appRole==="user"&&!f.public?(J(),me(m(W),{key:1,class:"create",size:"medium",ghost:"",loading:f.loading,onClick:ie(q=>F(f),["stop"])},{icon:w(()=>[b(m(ne),{icon:"mdi-light:delete",class:"text-base"})]),default:w(()=>[K(" 编辑应用 ")]),_:2},1032,["loading","onClick"])):ve("",!0)]),_:2},1024)])],8,pn))),128))])])]),b(m(ht),{show:l.value,title:"创建",style:{width:"90%","max-width":"640px"},"mask-closable":!1,"on-after-enter":H,"on-after-leave":N},{default:w(()=>[R("div",wn,[R("div",{class:"absolute top-4 left-5 cursor-pointer z-30",onClick:h[4]||(h[4]=f=>l.value=!1)},[R("span",xn,ce(m(o)),1)]),R("div",{class:"absolute top-3 right-3 cursor-pointer z-30",onClick:h[5]||(h[5]=f=>l.value=!1)},[b(m(ct),{size:"20",color:"#0e7a0d"},{default:w(()=>[b(m(ft))]),_:1})]),R("div",Rn,[b(m(pt),{ref_key:"formRef",ref:d,model:x.value,rules:V,"label-placement":"left","label-width":"auto","require-mark-placement":"right-hanging",style:{maxWidth:"640px"}},{default:w(()=>[b(m(Y),{label:"应用分类",path:"catId"},{default:w(()=>[b(m(kt),{value:x.value.catId,"onUpdate:value":h[6]||(h[6]=f=>x.value.catId=f),class:"border-2 border-black rounded-md",clearable:"",size:"medium","label-field":"name",placeholder:"请输入您的应用分类","value-field":"id",options:E.value},null,8,["value","options"])]),_:1}),b(m(Y),{label:"应用名称",path:"name"},{default:w(()=>[b(m(le),{value:x.value.name,"onUpdate:value":h[7]||(h[7]=f=>x.value.name=f),placeholder:"请输入您的应用名称",class:"border-2 border-black rounded-md",type:"name",maxlength:30,"show-name-on":"click",tabindex:"0"},null,8,["value"])]),_:1}),b(m(Y),{label:"预设指令",path:"preset"},{default:w(()=>[b(m(le),{value:x.value.preset,"onUpdate:value":h[8]||(h[8]=f=>x.value.preset=f),class:"border-2 border-black rounded-md",max:255,autosize:{minRows:3,maxRows:10},type:"textarea",placeholder:"请填写prompt预设指令（核心）"},null,8,["value"])]),_:1}),b(m(Y),{label:"应用描述",path:"des"},{default:w(()=>[b(m(le),{value:x.value.des,"onUpdate:value":h[9]||(h[9]=f=>x.value.des=f),class:"border-2 border-black rounded-md",autosize:{minRows:3,maxRows:10},type:"textarea",placeholder:"请对你的应用做以简要的描述以便于大家认识它！"},null,8,["value"])]),_:1}),b(m(Y),{label:"示例内容",path:"demoData"},{default:w(()=>[b(m(le),{value:x.value.demoData,"onUpdate:value":h[10]||(h[10]=f=>x.value.demoData=f),class:"border-2 border-black rounded-md",autosize:{minRows:3,maxRows:10},type:"textarea",placeholder:"请填写一个示例、方便快速告诉别人如何使用、每点击回车换行一次则是新增一条示例！"},null,8,["value"])]),_:1}),b(m(Y),{label:"应用Logo",path:"coverImg"},{default:w(()=>[b(m(Yt),{"on-update:file-list":c,"on-before-upload":L,max:1,"default-upload":!1,action:M.value,"default-file-list":i.value,"list-type":"image-card"},{default:w(()=>[K(" 点击上传 ")]),_:1},8,["action","default-file-list"])]),_:1}),b(m(Y),{label:"是否共享",path:"public"},{default:w(()=>[b(m(Lt),{value:x.value.public,"onUpdate:value":h[11]||(h[11]=f=>x.value.public=f),class:"switch rounded-full",disabled:s.value},null,8,["value","disabled"]),b(m(gt),{placement:"top-start",trigger:"hover"},{trigger:w(()=>[b(m(ne),{icon:"ri:error-warning-line",class:"text-base ml-3 cursor-pointer"})]),default:w(()=>[Cn,_n,kn,Ln,Tn]),_:1})]),_:1}),b(m(Y),{class:"mt-3"},{default:w(()=>[b(m(W),{block:"",type:"primary",disabled:r.value,loading:r.value,class:"start",onClick:U},{default:w(()=>[K(ce(m(u)),1)]),_:1},8,["disabled","loading"])]),_:1})]),_:1},8,["model"])])])]),_:1},8,["show"])],64))}});const In={class:"flex h-full w-full flex-col bg-white dark:bg-[#111114]"},Fn={class:"sticky left-0 right-0 top-0 z-40 border-b bg-white dark:border-b-neutral-800 dark:bg-[#111114]"},Un=Z({__name:"index",setup(e){return(t,n)=>(J(),ae("div",In,[R("header",Fn,[b(an)]),b(Bn)]))}}),Pn={class:"h-full dark:bg-[#24272e] transition-all"},Nn=Z({__name:"role",setup(e){const t=Rt(),{isMobile:n}=Pe(),r=I(()=>t.siderCollapsed),l=I(()=>n.value?["rounded-none","shadow-none"]:["rounded-md","shadow-md","dark:border-neutral-800"]),i=I(()=>["h-full",{"pl-[260px]":!n.value&&!r.value}]);return(d,p)=>(J(),ae("div",Pn,[R("div",{class:_e(["h-full overflow-hidden",m(l)])},[b(m(_t),{class:_e(["z-40 transition",m(i)]),"has-sider":""},{default:w(()=>[b(Ae),b(m(Ct),{class:"h-full"},{default:w(()=>[b(Un)]),_:1})]),_:1},8,["class"])],2)]))}});export{Nn as default};
