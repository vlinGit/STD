function r(l,o){let t,e;return function(...i){e=i,t||(t=setTimeout(()=>{l.apply(this,e),t=null},o))}}export{r as t};
