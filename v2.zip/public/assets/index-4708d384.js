import{aH as V,aI as _,aJ as L,d as q,e as C,be as O,ad as o,ax as oe,bf as se,bg as ie,bh as ne,bi as ae,aN as xe,aO as le,bj as ke,ba as J,aS as _e,a7 as Y,o as b,c as I,a as S,E as N,t as M,m as t,F as H,j as Se,k as x,_ as P,p as K,A as $e,s as z,l as E,G as we,Y as ce,C as ue,f as de,Z as Ce,D as pe,u as ge,r as R,w as U,h as Ie,a5 as Pe,af as ze,b as Be,O as De,ag as Z,bk as Ne,J as Q,n as ee,ah as Re,W as Te,X as We}from"./index-cdd1030a.js";import{N as Ae}from"./Popconfirm-186e1d10.js";import{N as te}from"./NumberAnimation-9c0224fa.js";import{N as Me}from"./LayoutSider-2a3099b5.js";const Ge=V([_("progress",{display:"inline-block"},[_("progress-icon",`
 color: var(--n-icon-color);
 transition: color .3s var(--n-bezier);
 `),L("line",`
 width: 100%;
 display: block;
 `,[_("progress-content",`
 display: flex;
 align-items: center;
 `,[_("progress-graph",{flex:1})]),_("progress-custom-content",{marginLeft:"14px"}),_("progress-icon",`
 width: 30px;
 padding-left: 14px;
 height: var(--n-icon-size-line);
 line-height: var(--n-icon-size-line);
 font-size: var(--n-icon-size-line);
 `,[L("as-text",`
 color: var(--n-text-color-line-outer);
 text-align: center;
 width: 40px;
 font-size: var(--n-font-size);
 padding-left: 4px;
 transition: color .3s var(--n-bezier);
 `)])]),L("circle, dashboard",{width:"120px"},[_("progress-custom-content",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 `),_("progress-text",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: inherit;
 font-size: var(--n-font-size-circle);
 color: var(--n-text-color-circle);
 font-weight: var(--n-font-weight-circle);
 transition: color .3s var(--n-bezier);
 white-space: nowrap;
 `),_("progress-icon",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: var(--n-icon-color);
 font-size: var(--n-icon-size-circle);
 `)]),L("multiple-circle",`
 width: 200px;
 color: inherit;
 `,[_("progress-text",`
 font-weight: var(--n-font-weight-circle);
 color: var(--n-text-color-circle);
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 transition: color .3s var(--n-bezier);
 `)]),_("progress-content",{position:"relative"}),_("progress-graph",{position:"relative"},[_("progress-graph-circle",[V("svg",{verticalAlign:"bottom"}),_("progress-graph-circle-fill",`
 stroke: var(--n-fill-color);
 transition:
 opacity .3s var(--n-bezier),
 stroke .3s var(--n-bezier),
 stroke-dasharray .3s var(--n-bezier);
 `,[L("empty",{opacity:0})]),_("progress-graph-circle-rail",`
 transition: stroke .3s var(--n-bezier);
 overflow: hidden;
 stroke: var(--n-rail-color);
 `)]),_("progress-graph-line",[L("indicator-inside",[_("progress-graph-line-rail",`
 height: 16px;
 line-height: 16px;
 border-radius: 10px;
 `,[_("progress-graph-line-fill",`
 height: inherit;
 border-radius: 10px;
 `),_("progress-graph-line-indicator",`
 background: #0000;
 white-space: nowrap;
 text-align: right;
 margin-left: 14px;
 margin-right: 14px;
 height: inherit;
 font-size: 12px;
 color: var(--n-text-color-line-inner);
 transition: color .3s var(--n-bezier);
 `)])]),L("indicator-inside-label",`
 height: 16px;
 display: flex;
 align-items: center;
 `,[_("progress-graph-line-rail",`
 flex: 1;
 transition: background-color .3s var(--n-bezier);
 `),_("progress-graph-line-indicator",`
 background: var(--n-fill-color);
 font-size: 12px;
 transform: translateZ(0);
 display: flex;
 vertical-align: middle;
 height: 16px;
 line-height: 16px;
 padding: 0 10px;
 border-radius: 10px;
 position: absolute;
 white-space: nowrap;
 color: var(--n-text-color-line-inner);
 transition:
 right .2s var(--n-bezier),
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `)]),_("progress-graph-line-rail",`
 position: relative;
 overflow: hidden;
 height: var(--n-rail-height);
 border-radius: 5px;
 background-color: var(--n-rail-color);
 transition: background-color .3s var(--n-bezier);
 `,[_("progress-graph-line-fill",`
 background: var(--n-fill-color);
 position: relative;
 border-radius: 5px;
 height: inherit;
 width: 100%;
 max-width: 0%;
 transition:
 background-color .3s var(--n-bezier),
 max-width .2s var(--n-bezier);
 `,[L("processing",[V("&::after",`
 content: "";
 background-image: var(--n-line-bg-processing);
 animation: progress-processing-animation 2s var(--n-bezier) infinite;
 `)])])])])])]),V("@keyframes progress-processing-animation",`
 0% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 100%;
 opacity: 1;
 }
 66% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 100% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 `)]),Le={success:o(se,null),error:o(ie,null),warning:o(ne,null),info:o(ae,null)},qe=q({name:"ProgressLine",props:{clsPrefix:{type:String,required:!0},percentage:{type:Number,default:0},railColor:String,railStyle:[String,Object],fillColor:String,status:{type:String,required:!0},indicatorPlacement:{type:String,required:!0},indicatorTextColor:String,unit:{type:String,default:"%"},processing:{type:Boolean,required:!0},showIndicator:{type:Boolean,required:!0},height:[String,Number],railBorderRadius:[String,Number],fillBorderRadius:[String,Number]},setup(e,{slots:v}){const m=C(()=>O(e.height)),g=C(()=>e.railBorderRadius!==void 0?O(e.railBorderRadius):e.height!==void 0?O(e.height,{c:.5}):""),s=C(()=>e.fillBorderRadius!==void 0?O(e.fillBorderRadius):e.railBorderRadius!==void 0?O(e.railBorderRadius):e.height!==void 0?O(e.height,{c:.5}):"");return()=>{const{indicatorPlacement:l,railColor:$,railStyle:u,percentage:f,unit:d,indicatorTextColor:h,status:y,showIndicator:w,fillColor:n,processing:a,clsPrefix:r}=e;return o("div",{class:`${r}-progress-content`,role:"none"},o("div",{class:`${r}-progress-graph`,"aria-hidden":!0},o("div",{class:[`${r}-progress-graph-line`,{[`${r}-progress-graph-line--indicator-${l}`]:!0}]},o("div",{class:`${r}-progress-graph-line-rail`,style:[{backgroundColor:$,height:m.value,borderRadius:g.value},u]},o("div",{class:[`${r}-progress-graph-line-fill`,a&&`${r}-progress-graph-line-fill--processing`],style:{maxWidth:`${e.percentage}%`,backgroundColor:n,height:m.value,lineHeight:m.value,borderRadius:s.value}},l==="inside"?o("div",{class:`${r}-progress-graph-line-indicator`,style:{color:h}},v.default?v.default():`${f}${d}`):null)))),w&&l==="outside"?o("div",null,v.default?o("div",{class:`${r}-progress-custom-content`,style:{color:h},role:"none"},v.default()):y==="default"?o("div",{role:"none",class:`${r}-progress-icon ${r}-progress-icon--as-text`,style:{color:h}},f,d):o("div",{class:`${r}-progress-icon`,"aria-hidden":!0},o(oe,{clsPrefix:r},{default:()=>Le[y]}))):null)}}}),Oe={success:o(se,null),error:o(ie,null),warning:o(ne,null),info:o(ae,null)},Ke=q({name:"ProgressCircle",props:{clsPrefix:{type:String,required:!0},status:{type:String,required:!0},strokeWidth:{type:Number,required:!0},fillColor:String,railColor:String,railStyle:[String,Object],percentage:{type:Number,default:0},offsetDegree:{type:Number,default:0},showIndicator:{type:Boolean,required:!0},indicatorTextColor:String,unit:String,viewBoxWidth:{type:Number,required:!0},gapDegree:{type:Number,required:!0},gapOffsetDegree:{type:Number,default:0}},setup(e,{slots:v}){function m(g,s,l){const{gapDegree:$,viewBoxWidth:u,strokeWidth:f}=e,d=50,h=0,y=d,w=0,n=2*d,a=50+f/2,r=`M ${a},${a} m ${h},${y}
      a ${d},${d} 0 1 1 ${w},${-n}
      a ${d},${d} 0 1 1 ${-w},${n}`,k=Math.PI*2*d,p={stroke:l,strokeDasharray:`${g/100*(k-$)}px ${u*8}px`,strokeDashoffset:`-${$/2}px`,transformOrigin:s?"center":void 0,transform:s?`rotate(${s}deg)`:void 0};return{pathString:r,pathStyle:p}}return()=>{const{fillColor:g,railColor:s,strokeWidth:l,offsetDegree:$,status:u,percentage:f,showIndicator:d,indicatorTextColor:h,unit:y,gapOffsetDegree:w,clsPrefix:n}=e,{pathString:a,pathStyle:r}=m(100,0,s),{pathString:k,pathStyle:p}=m(f,$,g),c=100+l;return o("div",{class:`${n}-progress-content`,role:"none"},o("div",{class:`${n}-progress-graph`,"aria-hidden":!0},o("div",{class:`${n}-progress-graph-circle`,style:{transform:w?`rotate(${w}deg)`:void 0}},o("svg",{viewBox:`0 0 ${c} ${c}`},o("g",null,o("path",{class:`${n}-progress-graph-circle-rail`,d:a,"stroke-width":l,"stroke-linecap":"round",fill:"none",style:r})),o("g",null,o("path",{class:[`${n}-progress-graph-circle-fill`,f===0&&`${n}-progress-graph-circle-fill--empty`],d:k,"stroke-width":l,"stroke-linecap":"round",fill:"none",style:p}))))),d?o("div",null,v.default?o("div",{class:`${n}-progress-custom-content`,role:"none"},v.default()):u!=="default"?o("div",{class:`${n}-progress-icon`,"aria-hidden":!0},o(oe,{clsPrefix:n},{default:()=>Oe[u]})):o("div",{class:`${n}-progress-text`,style:{color:h},role:"none"},o("span",{class:`${n}-progress-text__percentage`},f),o("span",{class:`${n}-progress-text__unit`},y))):null)}}});function re(e,v,m=100){return`m ${m/2} ${m/2-e} a ${e} ${e} 0 1 1 0 ${2*e} a ${e} ${e} 0 1 1 0 -${2*e}`}const Ee=q({name:"ProgressMultipleCircle",props:{clsPrefix:{type:String,required:!0},viewBoxWidth:{type:Number,required:!0},percentage:{type:Array,default:[0]},strokeWidth:{type:Number,required:!0},circleGap:{type:Number,required:!0},showIndicator:{type:Boolean,required:!0},fillColor:{type:Array,default:()=>[]},railColor:{type:Array,default:()=>[]},railStyle:{type:Array,default:()=>[]}},setup(e,{slots:v}){const m=C(()=>e.percentage.map((s,l)=>`${Math.PI*s/100*(e.viewBoxWidth/2-e.strokeWidth/2*(1+2*l)-e.circleGap*l)*2}, ${e.viewBoxWidth*8}`));return()=>{const{viewBoxWidth:g,strokeWidth:s,circleGap:l,showIndicator:$,fillColor:u,railColor:f,railStyle:d,percentage:h,clsPrefix:y}=e;return o("div",{class:`${y}-progress-content`,role:"none"},o("div",{class:`${y}-progress-graph`,"aria-hidden":!0},o("div",{class:`${y}-progress-graph-circle`},o("svg",{viewBox:`0 0 ${g} ${g}`},h.map((w,n)=>o("g",{key:n},o("path",{class:`${y}-progress-graph-circle-rail`,d:re(g/2-s/2*(1+2*n)-l*n,s,g),"stroke-width":s,"stroke-linecap":"round",fill:"none",style:[{strokeDashoffset:0,stroke:f[n]},d[n]]}),o("path",{class:[`${y}-progress-graph-circle-fill`,w===0&&`${y}-progress-graph-circle-fill--empty`],d:re(g/2-s/2*(1+2*n)-l*n,s,g),"stroke-width":s,"stroke-linecap":"round",fill:"none",style:{strokeDasharray:m.value[n],strokeDashoffset:0,stroke:u[n]}})))))),$&&v.default?o("div",null,o("div",{class:`${y}-progress-text`},v.default())):null)}}}),je=Object.assign(Object.assign({},le.props),{processing:Boolean,type:{type:String,default:"line"},gapDegree:Number,gapOffsetDegree:Number,status:{type:String,default:"default"},railColor:[String,Array],railStyle:[String,Array],color:[String,Array],viewBoxWidth:{type:Number,default:100},strokeWidth:{type:Number,default:7},percentage:[Number,Array],unit:{type:String,default:"%"},showIndicator:{type:Boolean,default:!0},indicatorPosition:{type:String,default:"outside"},indicatorPlacement:{type:String,default:"outside"},indicatorTextColor:String,circleGap:{type:Number,default:1},height:Number,borderRadius:[String,Number],fillBorderRadius:[String,Number],offsetDegree:Number}),It=q({name:"Progress",props:je,setup(e){const v=C(()=>e.indicatorPlacement||e.indicatorPosition),m=C(()=>{if(e.gapDegree||e.gapDegree===0)return e.gapDegree;if(e.type==="dashboard")return 75}),{mergedClsPrefixRef:g,inlineThemeDisabled:s}=xe(e),l=le("Progress","-progress",Ge,ke,e,g),$=C(()=>{const{status:f}=e,{common:{cubicBezierEaseInOut:d},self:{fontSize:h,fontSizeCircle:y,railColor:w,railHeight:n,iconSizeCircle:a,iconSizeLine:r,textColorCircle:k,textColorLineInner:p,textColorLineOuter:c,lineBgProcessing:i,fontWeightCircle:D,[J("iconColor",f)]:T,[J("fillColor",f)]:G}}=l.value;return{"--n-bezier":d,"--n-fill-color":G,"--n-font-size":h,"--n-font-size-circle":y,"--n-font-weight-circle":D,"--n-icon-color":T,"--n-icon-size-circle":a,"--n-icon-size-line":r,"--n-line-bg-processing":i,"--n-rail-color":w,"--n-rail-height":n,"--n-text-color-circle":k,"--n-text-color-line-inner":p,"--n-text-color-line-outer":c}}),u=s?_e("progress",C(()=>e.status[0]),$,e):void 0;return{mergedClsPrefix:g,mergedIndicatorPlacement:v,gapDeg:m,cssVars:s?void 0:$,themeClass:u==null?void 0:u.themeClass,onRender:u==null?void 0:u.onRender}},render(){const{type:e,cssVars:v,indicatorTextColor:m,showIndicator:g,status:s,railColor:l,railStyle:$,color:u,percentage:f,viewBoxWidth:d,strokeWidth:h,mergedIndicatorPlacement:y,unit:w,borderRadius:n,fillBorderRadius:a,height:r,processing:k,circleGap:p,mergedClsPrefix:c,gapDeg:i,gapOffsetDegree:D,themeClass:T,$slots:G,onRender:j}=this;return j==null||j(),o("div",{class:[T,`${c}-progress`,`${c}-progress--${e}`,`${c}-progress--${s}`],style:v,"aria-valuemax":100,"aria-valuemin":0,"aria-valuenow":f,role:e==="circle"||e==="line"||e==="dashboard"?"progressbar":"none"},e==="circle"||e==="dashboard"?o(Ke,{clsPrefix:c,status:s,showIndicator:g,indicatorTextColor:m,railColor:l,fillColor:u,railStyle:$,offsetDegree:this.offsetDegree,percentage:f,viewBoxWidth:d,strokeWidth:h,gapDegree:i===void 0?e==="dashboard"?75:0:i,gapOffsetDegree:D,unit:w},G):e==="line"?o(qe,{clsPrefix:c,status:s,showIndicator:g,indicatorTextColor:m,railColor:l,fillColor:u,railStyle:$,percentage:f,processing:k,indicatorPlacement:y,unit:w,fillBorderRadius:a,railBorderRadius:n,height:r},G):e==="multiple-circle"?o(Ee,{clsPrefix:c,strokeWidth:h,railColor:l,fillColor:u,railStyle:$,viewBoxWidth:d,percentage:f,showIndicator:g,circleGap:p},G):null)}});function Ue(e,v){let m;return(...g)=>{const s=()=>{clearTimeout(m),e(...g)};clearTimeout(m),m=setTimeout(s,v)}}const Ve={class:"mb-2 text-xs text-neutral-400 font-bold"},Xe={class:"ml-1"},He=["onClick"],Ye={class:"relative flex-1 overflow-hidden break-all text-ellipsis whitespace-nowrap"},Fe={key:1},Je={key:0,class:"absolute z-10 flex visible right-1"},Ze=["onClick"],Qe={class:"p-1"},et={key:0,class:"p-1"},tt={class:"p-1"},rt=q({__name:"ListItem",props:{dataSources:null,title:null},emits:["update","delete","sticky","select"],setup(e,{emit:v}){const m=e,g=m.dataSources,s=Y();async function l(a){v("select",a)}function $(a,r,k){k==null||k.stopPropagation(),a.isEdit=r}async function u(a,r){r==null||r.stopPropagation(),await s.updateGroupInfo({isSticky:!a.isSticky,groupId:a.uuid}),await s.queryMyGroup()}async function f(a,r){r==null||r.stopPropagation(),v("delete",a)}const d=Ue(f,600);async function h(a){const{uuid:r,title:k}=a;a.isEdit=!1,await s.updateGroupInfo({groupId:r,title:k}),await s.queryMyGroup()}async function y(a,r){r==null||r.stopPropagation(),r.key==="Enter"&&h(a)}function w(a,r){r==null||r.stopPropagation(),h(a)}function n(a){return s.active===a}return(a,r)=>{var k;return b(),I(H,null,[S("p",Ve,[N(M(m.title)+" ",1),S("span",Xe,"("+M((k=t(g))==null?void 0:k.length)+")",1)]),(b(!0),I(H,null,Se(t(g),p=>(b(),I("div",{key:`${p.uuid}`},[S("a",{class:we(["relative flex items-center gap-3 px-3 py-2.5 break-all rounded-md cursor-pointer hover:bg-neutral-100 group dark:border-neutral-800 dark:hover:bg-[#24272e]",n(p.uuid)&&["border-[#3076FD]","bg-neutral-100","text-[#000]","dark:bg-[#24272e]","dark:border-[#3076fd]","pr-20"]]),onClick:c=>l(p)},[S("span",null,[x(t(P),{icon:p.isSticky?"ri:pushpin-2-line":p.appId?"icon-park-outline:application-one":"eos-icons:typing"},null,8,["icon"])]),S("div",Ye,[p.isEdit?(b(),K(t($e),{key:0,value:p.title,"onUpdate:value":c=>p.title=c,size:"tiny",onKeypress:c=>y(p,c)},null,8,["value","onUpdate:value","onKeypress"])):(b(),I("span",Fe,M(p.title),1))]),n(p.uuid)?(b(),I("div",Je,[p.isEdit?(b(),I("button",{key:0,class:"p-1",onClick:c=>w(p,c)},[x(t(P),{icon:"ri:save-line"})],8,Ze)):(b(),I(H,{key:1},[S("button",Qe,[x(t(P),{icon:p.isSticky?"ri:unpin-line":"ri:pushpin-line",onClick:c=>u(p,c)},null,8,["icon","onClick"])]),p.appId?z("",!0):(b(),I("button",et,[x(t(P),{icon:"ri:edit-line",onClick:c=>$(p,!0,c)},null,8,["onClick"])])),x(t(Ae),{placement:"bottom",onPositiveClick:c=>t(d)(p,c)},{trigger:E(()=>[S("button",tt,[x(t(P),{icon:"ri:delete-bin-line"})])]),default:E(()=>[N(" "+M(a.$t("chat.deleteHistoryConfirm")),1)]),_:2},1032,["onPositiveClick"])],64))])):z("",!0)],10,He)]))),128))],64)}}});const X=ce(rt,[["__scopeId","data-v-78d8ea28"]]),ot={class:"flex flex-col gap-3 text-sm"},st={key:0,class:"flex flex-col items-center mt-4 text-center text-neutral-300"},it=q({__name:"List",setup(e){const{isMobile:v}=ue(),m=de(),g=Ce(),s=pe(),l=Y(),$=ge(),u=R(100),f=C(()=>l.groupList),d=C(()=>l.groupKeyWord);U(f,()=>u.value=u.value+1),U(d,()=>u.value=u.value+1),C(()=>$.isLogin);function h(i){const T=new Date(i).getTime()+8*60*60*1e3;return new Date(T).getTime()}const y=new Date().setHours(0,0,0,0),w=C(()=>f.value.filter(i=>d.value?i.title.includes(d.value)&&i.isSticky:i.isSticky)),n=C(()=>f.value.filter(i=>d.value?i.title.includes(d.value)&&!i.isSticky&&i.appId:!i.isSticky&&i.appId)),a=C(()=>f.value.filter(i=>d.value?i.title.includes(d.value)&&!i.isSticky&&!i.appId&&h(i.createdAt)>=y:!i.isSticky&&!i.appId&&h(i.createdAt)>=y)),r=C(()=>f.value.filter(i=>d.value?i.title.includes(d.value)&&!i.isSticky&&!i.appId&&h(i.createdAt)<y:!i.isSticky&&!i.appId&&h(i.createdAt)<y));async function k(i){const{uuid:D}=i;c(D)||(await l.setActiveGroup(D),g.name!=="Chat"&&m.push("/chat"),v.value&&s.setSiderCollapsed(!0))}async function p(i){event==null||event.stopPropagation(),await l.deleteGroup(i),await l.queryMyGroup(),v.value&&s.setSiderCollapsed(!0)}function c(i){return l.active===i}return Ie(()=>{l.queryMyGroup()}),(i,D)=>(b(),K(t(Pe),{class:"px-4"},{default:E(()=>[S("div",ot,[t(f).length?(b(),I(H,{key:1},[t(w).length?(b(),K(X,{key:1e3+u.value,title:"置顶","data-sources":t(w),onSelect:k,onDelete:p},null,8,["data-sources"])):z("",!0),t(n).length?(b(),K(X,{key:2e3+u.value,title:"应用分类组","data-sources":t(n),onSelect:k,onDelete:p},null,8,["data-sources"])):z("",!0),t(a).length?(b(),K(X,{key:3e3+u.value,title:"今天","data-sources":t(a),onSelect:k,onDelete:p},null,8,["data-sources"])):z("",!0),t(r).length?(b(),K(X,{key:4e3+u.value,title:"其他","data-sources":t(r),onSelect:k,onDelete:p},null,8,["data-sources"])):z("",!0)],64)):(b(),I("div",st,[x(t(P),{icon:"ri:inbox-line",class:"mb-2 text-3xl"}),S("span",null,M(i.$t("common.noData")),1)]))])]),_:1}))}}),fe=e=>(Te("data-v-e6202051"),e=e(),We(),e),nt={class:"flex flex-col h-full flex-1 min-h-0"},at={class:"flex items-center space-x-2 bg-white dark:bg-gray-900 h-12 px-3 border-b border-t-gray-100 dark:border-b dark:border-b-gray-800 text-lg mb-2"},lt={class:"flex-1 relative"},ct={class:"search-container"},ut={class:"flex-1 min-h-0 pb-4 overflow-hidden"},dt={key:0,class:"px-2 py-2 flex items-center border-t dark:border-t-neutral-800"},pt={class:"p-4 border-t dark:border-t-neutral-800 flex flex-col"},gt={key:0,class:"my-1 flex items-center select-none"},ft={key:1,class:"my-1 flex items-center select-none"},ht={key:2,class:"my-1 flex items-center select-none"},yt={key:3,class:"my-1 flex items-center select-none"},mt={key:4,class:"my-1 flex items-center select-none"},vt={key:5,class:"my-1 flex items-center select-none"},bt={class:"flex justify-between my-3"},xt=fe(()=>S("span",{class:"mr-2"},"公告栏",-1)),kt=fe(()=>S("span",{class:"mr-3"},"工作台",-1)),_t=q({__name:"index",setup(e){const v=ze(),m=de(),g=pe(),s=Y(),l=ge();Be();const $=R(null),u=R(null),f=C(()=>l.userBalance),d=De(),h=C(()=>s==null?void 0:s.activeModelKeyDeductType),y=C(()=>s==null?void 0:s.activeModelKeyPrice),w=R(0),n=R(0),a=R(0),r=R(0),k=R(!1),p=R(null);U(()=>l.userBalance.useModel3Token,(W,B)=>{var A;w.value=B||0,n.value=W||0,(A=$.value)==null||A.play()},{immediate:!0,flush:"post"}),U(()=>l.userBalance.useModel4Token,(W,B)=>{var A;a.value=B||0,r.value=W||0,(A=u.value)==null||A.play()},{immediate:!0,flush:"post"});const{isMobile:c}=ue(),i=R(!1),D=C(()=>g.siderCollapsed),T=R("");function G(W){const B=W.target.value;T.value=B,s.setGroupKeyWord(B)}function j(){k.value=!1}function he(){m.push("/role")}async function ye(){try{i.value=!0,await s.addNewChatGroup(),await s.queryMyGroup(),i.value=!1,c.value&&g.setSiderCollapsed(!0)}catch{i.value=!1}}async function me(){d.warning({title:"清空分组",content:"是否删除所有非置顶的对话组？",positiveText:"确认删除",negativeText:"再想想",onPositiveClick:async()=>{await s.delAllGroup()}})}function F(){g.setSiderCollapsed(!D.value)}const ve=C(()=>c.value?{position:"fixed",zIndex:50}:{}),be=C(()=>c.value?{paddingBottom:"env(safe-area-inset-bottom)"}:{});return U(c,W=>{g.setSiderCollapsed(W)},{immediate:!0,flush:"post"}),(W,B)=>(b(),I("div",null,[x(t(Me),{collapsed:t(D),"collapsed-width":0,width:260,"show-trigger":t(c)?!1:"arrow-circle","collapse-mode":"transform",position:"absolute",bordered:"",style:ee(t(ve)),onUpdateCollapsed:F},{default:E(()=>[S("div",{class:"flex flex-col h-full bg-[#fafbfc] dark:bg-[#18181c]",style:ee(t(be))},[S("main",nt,[S("div",at,[S("div",lt,[S("div",ct,[Z(S("input",{ref_key:"searchRef",ref:p,"onUpdate:modelValue":B[0]||(B[0]=A=>T.value=A),type:"text",placeholder:"搜索历史对话",class:"search",onBlur:j,onInput:G},null,544),[[Ne,T.value]]),S("button",{type:"button",class:"add-button",onClick:ye},[x(t(P),{icon:"material-symbols-light:add",class:"h-6 w-6"})]),S("button",{type:"button",class:"delete-button",onClick:me},[x(t(P),{icon:"material-symbols-light:delete-outline",class:"h-6 w-6"})])])])]),S("div",ut,[x(it)]),N("> "),t(c)?z("",!0):(b(),I("div",dt,[S("div",{class:"container flex items-center",onClick:B[1]||(B[1]=A=>t(v).updateGoodsDialog(!0))},[x(t(P),{icon:"material-symbols:shopping-bag-outline",class:"mr-2",style:{"font-size":"20px"}}),N(" 选购您的方案 ")])])),S("div",pt,[t(h)===1?(b(),I("div",gt,[x(t(P),{icon:"material-symbols:account-balance-wallet-outline",class:"ml-0 mr-2 text-base",style:{"font-size":"20px"}}),N("普通额度： "+M(`${t(f).sumModel3Count||0} 积分`),1)])):z("",!0),t(h)===1?(b(),I("div",ft,[x(t(P),{icon:"ic:twotone-hourglass-top",class:"ml-0 mr-2 text-base",style:{"font-size":"20px"}}),N(" 我已使用： "),x(t(te),{ref_key:"model3AnimationInstRef",ref:$,from:w.value,to:n.value},null,8,["from","to"]),N(" Token ")])):z("",!0),t(h)===1?(b(),I("div",ht,[x(t(P),{icon:"mingcute:bill-line",class:"ml-0 mr-2 text-base",style:{"font-size":"20px"}}),N(" 模型费用： "+M(`${t(y)||0}积分 / 次对话`),1)])):z("",!0),t(h)===2?(b(),I("div",yt,[x(t(P),{icon:"ic:twotone-hourglass-top",class:"ml-2 mr-2 text-base"}),N("我已使用： "),x(t(te),{ref_key:"model4AnimationInstRef",ref:u,from:a.value,to:r.value},null,8,["from","to"]),N(" Token ")])):z("",!0),t(h)===2?(b(),I("div",mt,[x(t(P),{icon:"material-symbols:account-balance-wallet-outline",class:"ml-2 mr-2 text-base"}),N("高级额度： "+M(`${t(f).sumModel4Count||0} 积分`),1)])):z("",!0),t(h)===2?(b(),I("div",vt,[x(t(P),{icon:"mingcute:bill-line",class:"ml-4 mr-4 text-base"}),N("模型费用： "+M(`${t(y)||0}积分 / 次对话`),1)])):z("",!0),S("div",bt,[x(t(Q),{class:"green-button",onClick:B[2]||(B[2]=A=>t(v).updateNoticeDialog(!0))},{default:E(()=>[x(t(P),{icon:"mdi:notice-board",class:"ml-2 mr-2 text-sm"}),xt]),_:1}),x(t(Q),{class:"green-button",onClick:he},{default:E(()=>[x(t(P),{icon:"ri:emoji-sticker-line",class:"ml-2 mr-2 text-sm"}),kt]),_:1})])])])],4)]),_:1},8,["collapsed","show-trigger","style"]),t(c)?Z((b(),I("div",{key:0,class:"fixed inset-0 z-40 bg-black/40",onClick:F},null,512)),[[Re,!t(D)]]):z("",!0)]))}});const Pt=ce(_t,[["__scopeId","data-v-e6202051"]]);export{It as N,Pt as S};
