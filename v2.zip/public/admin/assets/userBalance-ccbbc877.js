
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{Y as e}from"./index-31dbc7f6.js";const o={upgradeBalance:a=>e.post("balance/upgradeBalance",a),queryUserAccountLog:a=>e.get("balance/accountLog",{params:a})};export{o as a};
