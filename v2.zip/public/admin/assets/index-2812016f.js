
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as i,y as d,r as c,B as g,o,I as p,f,c as l,b as e,J as r,t as h,G as k,h as y,n as x}from"./index-31dbc7f6.js";const B="/admin/assets/logo-71242da6.png",w=["src"],C={key:1},L=i({name:"Logo"}),v=i({...L,props:{showLogo:{type:Boolean,default:!0},showTitle:{type:Boolean,default:!0}},setup(s){const n=d(),a=c("Yi-Ai"),_=c(B),u=g(()=>{const t={};return n.settings.home.enable&&(t.name="home"),t});return(t,S)=>{const m=y("router-link");return o(),p(m,{to:e(u),class:k(["title",{"is-link":e(n).settings.home.enable}]),title:e(a)},{default:f(()=>[s.showLogo?(o(),l("img",{key:0,src:e(_),class:"logo"},null,8,w)):r("",!0),s.showTitle?(o(),l("span",C,h(e(a)),1)):r("",!0)]),_:1},8,["to","class","title"])}}});const I=x(v,[["__scopeId","data-v-06c5f006"]]);export{I as default};
