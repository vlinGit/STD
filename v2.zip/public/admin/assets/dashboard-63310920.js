
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{Y as i}from"./index-31dbc7f6.js";const s={getBaseInfo:t=>i.get("/statistic/base",{params:t}),getChatStatistic:t=>i.get("/statistic/chatStatistic",{params:t}),getBaiduVisit:t=>i.get("/statistic/baiduVisit",{params:t})};export{s as default};
