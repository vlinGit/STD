
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{Y as o}from"./index-31dbc7f6.js";const g={queryAllConfig:()=>o.get("config/queryAll"),queryGptKeys:()=>o.get("config/queryGptKeys"),setGptKeys:t=>o.post("config/setGptKeys",t),queryConfig:t=>o.post("config/query",t),copyright:()=>o.get("config/copyright"),setConfig:t=>o.post("config/set",t)};export{g as a};
