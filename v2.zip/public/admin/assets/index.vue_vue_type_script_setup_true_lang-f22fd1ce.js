
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as o,Z as c,B as a,o as r,I as i,$ as l,b as e,a0 as m}from"./index-31dbc7f6.js";const d=o({__name:"index",props:{icon:null},setup(t){const s=c(),n=a(()=>({class:s.class||"",style:s.style||"width: 2em, height: 2em"}));return(p,u)=>(r(),i(e(m),l({icon:t.icon},e(n)),null,16,["icon"]))}});export{d as _};
