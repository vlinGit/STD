
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as a,r as d,y as g,x as h,o as c,c as n,b as s,t as u,J as l,p as f,i as y,a as r,g as m,n as S}from"./index-31dbc7f6.js";import{a as x}from"./config-23746dcc.js";const i=t=>(f("data-v-57c7df6c"),t=t(),y(),t),C={class:"copyright"},v=i(()=>r("span",null,"Copyright",-1)),k=i(()=>r("span",{class:"icon"},"©",-1)),I=["href"],b=a({name:"Copyright"}),B=a({...b,setup(t){const e=d({copyrightTitle:"NineAi Admin",copyrightUrl:"/"});async function _(){const o=await x.copyright();o.success&&(e.value=o.data)}m();const p=g();return h(()=>{_()}),(o,N)=>(c(),n("footer",C,[v,k,s(p).settings.copyright.beian?(c(),n("a",{key:0,href:s(e).copyrightUrl,target:"_blank",rel:"noopener"},u(s(e).copyrightTitle),9,I)):l("",!0)]))}});const T=S(B,[["__scopeId","data-v-57c7df6c"]]);export{T as _};
