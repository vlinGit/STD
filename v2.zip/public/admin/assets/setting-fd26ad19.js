
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{_ as f}from"./index-ca1777fd.js";import{d as c,r as h,o as b,c as v,e as s,f as o,a as e,k as g,h as n,p as x,i as y,m as k,n as w,q as a}from"./index-31dbc7f6.js";const _=t=>(x("data-v-5c060eb2"),t=t(),y(),t),C=_(()=>e("h2",null,"安全设置",-1)),I={class:"setting-list"},S={class:"item"},q=_(()=>e("div",{class:"content"},[e("div",{class:"title"}," 账户密码 "),e("div",{class:"desc"}," 当前密码强度：强 ")],-1)),B={class:"action"},N=c({name:"PersonalSetting"}),i=c({...N,setup(t){const l=k();h({headimg:"",mobile:"",name:"",qq:"",wechat:""});function d(){l.push({name:"personalEditPassword"})}return(P,V)=>{const p=n("el-button"),r=n("el-tab-pane"),u=n("el-tabs"),m=f;return b(),v("div",null,[s(m,null,{default:o(()=>[s(u,{"tab-position":"left",style:{height:"600px"}},{default:o(()=>[s(r,{label:"安全设置",class:"security"},{default:o(()=>[C,e("div",I,[e("div",S,[q,e("div",B,[s(p,{type:"primary",text:"",onClick:d},{default:o(()=>[g(" 修改 ")]),_:1})])])])]),_:1})]),_:1})]),_:1})])}}});typeof a=="function"&&a(i);const T=w(i,[["__scopeId","data-v-5c060eb2"]]);export{T as default};
