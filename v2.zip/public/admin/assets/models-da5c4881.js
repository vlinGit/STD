
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{Y as o}from"./index-31dbc7f6.js";const d={queryModels:e=>o.get("models/query",{params:e}),setModels:e=>o.post("models/setModel",e),delModels:e=>o.post("models/delModel",e)};export{d as A};
