
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{Y as e}from"./index-31dbc7f6.js";const c={queryAllPackage:a=>e.get("crami/queryAllPackage",{params:a}),updatePackage:a=>e.post("crami/updatePackage",a),createPackage:a=>e.post("crami/createPackage",a),delPackage:a=>e.post("crami/delPackage",a),queryAllCrami:a=>e.get("crami/queryAllCrami",{params:a}),delCrami:a=>e.post("crami/delCrami",a),createCrami:a=>e.post("crami/createCrami",a),batchDelCrami:a=>e.post("crami/batchDelCrami",a)};export{c as A};
