
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as t,x as n,o as a,c as r,m as s,q as e}from"./index-31dbc7f6.js";const c=t({__name:"reload",setup(u){const o=s();return n(()=>{o.go(-1)}),(p,_)=>(a(),r("div"))}});typeof e=="function"&&e(c);export{c as default};
