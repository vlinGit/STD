
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{y as u,A as i,ah as o}from"./index-31dbc7f6.js";function a(){const t=u(),e=i();function s(n){e.setActived(n),t.settings.menu.switchMainMenuAndPageJump&&o.push(e.sidebarMenusFirstDeepestPath)}return{switchTo:s}}export{a as u};
