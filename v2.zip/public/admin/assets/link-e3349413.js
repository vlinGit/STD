
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{_ as m}from"./index-ca1777fd.js";import{d as i,o as s,c as k,e as t,f as e,I as f,a,t as v,b as _,k as h,T as w,g,_ as x,h as c,p as y,i as I,n as V}from"./index-31dbc7f6.js";const b=n=>(y("data-v-721d0a4d"),n=n(),I(),n),B={class:"link-view"},C={class:"container"},S=b(()=>a("div",{class:"title"}," 是否访问此链接 ",-1)),N={class:"link"},T=i({name:"LinkView"}),L=i({...T,setup(n){const o=g();function l(){window.open(o.meta.link,"_blank")}return(D,E)=>{const d=x,p=c("el-icon"),r=c("el-button"),u=m;return s(),k("div",B,[t(w,{name:"link",mode:"out-in",appear:""},{default:e(()=>[(s(),f(u,{key:_(o).meta.link,title:"⚠️访问提醒"},{default:e(()=>[a("div",C,[S,a("div",N,v(_(o).meta.link),1),t(r,{type:"primary",plain:"",round:"",onClick:l},{icon:e(()=>[t(p,null,{default:e(()=>[t(d,{name:"ep:link"})]),_:1})]),default:e(()=>[h(" 立即访问 ")]),_:1})])]),_:1}))]),_:1})])}}});const j=V(L,[["__scopeId","data-v-721d0a4d"]]);export{j as default};
